(() => {
    const UI_ID = 'k12ext-video-complete';
    const BUTTON_ID = 'k12ext-run-button';
    const STATUS_ID = 'k12ext-status';
    const SUPPORTED_PATHNAME = /^\/\d+\/page\/LMS\/Lesson\/Courseware\/learn\/[^/?#]+$/i;
    const VIDEO_COMPLETE_ENDPOINT = 'https://hcm.k12online.vn/api/LMS/Learning/CourseResult/Video/complete';
    const MARK_COMPLETE_ENDPOINT = 'https://hcm.k12online.vn/api/LMS/Learning/Courseware/markComplete';
    const GUARD_INTERVAL_MS = 2000;

    const state = {
        isRunning: false,
        observer: null,
        historyPatched: false,
        confirmedVideoPage: false,
        confirmedUrl: '',
        guardTimer: null,
        quickButtonEnabled: true
    };

    function isCoursewarePageUrl() {
        return location.hostname === 'hcm.k12online.vn'
            && SUPPORTED_PATHNAME.test(location.pathname);
    }

    function hasVideoElement(sourceDocument = document) {
        return Boolean(
            sourceDocument.querySelector(
                '#video-upload, .video-loadDetail video, video source[type^="video/"], .video-loadDetail'
            )
        );
    }

    function hasVideoScriptMarker(sourceDocument = document) {
        try {
            return getInlineScriptSource(sourceDocument).includes('LMS.Learning.Lesson.Courseware.Video');
        } catch (_) {
            return false;
        }
    }

    function detectVideoPage() {
        if (!isCoursewarePageUrl()) {
            return false;
        }

        if (state.confirmedVideoPage && state.confirmedUrl === location.href) {
            return true;
        }

        if (state.confirmedUrl !== location.href) {
            state.confirmedVideoPage = false;
        }

        if (hasVideoElement() || hasVideoScriptMarker()) {
            state.confirmedVideoPage = true;
            state.confirmedUrl = location.href;
            return true;
        }

        return false;
    }

    function getQueryValue(name, pageUrl = location.href) {
        try {
            return new URL(pageUrl, location.href).searchParams.get(name) || '';
        } catch (_) {
            return '';
        }
    }

    function getInlineScriptSource(sourceDocument = document) {
        return Array.from(sourceDocument.scripts, (script) => script.textContent || '').join('\n');
    }

    function findObjectEnd(source, startIndex) {
        let depth = 0;
        let inSingleQuote = false;
        let inDoubleQuote = false;
        let inTemplateLiteral = false;
        let isEscaped = false;

        for (let index = startIndex; index < source.length; index += 1) {
            const char = source[index];

            if (isEscaped) {
                isEscaped = false;
                continue;
            }

            if ((inSingleQuote || inDoubleQuote || inTemplateLiteral) && char === '\\') {
                isEscaped = true;
                continue;
            }

            if (inSingleQuote) {
                if (char === '\'') {
                    inSingleQuote = false;
                }
                continue;
            }

            if (inDoubleQuote) {
                if (char === '"') {
                    inDoubleQuote = false;
                }
                continue;
            }

            if (inTemplateLiteral) {
                if (char === '`') {
                    inTemplateLiteral = false;
                }
                continue;
            }

            if (char === '\'') {
                inSingleQuote = true;
                continue;
            }

            if (char === '"') {
                inDoubleQuote = true;
                continue;
            }

            if (char === '`') {
                inTemplateLiteral = true;
                continue;
            }

            if (char === '{') {
                depth += 1;
                continue;
            }

            if (char === '}') {
                depth -= 1;

                if (depth === 0) {
                    return index;
                }
            }
        }

        return -1;
    }

    function extractVideoConfigBlock(source) {
        const markers = [
            "'LMS.Learning.Lesson.Courseware.Video'",
            '"LMS.Learning.Lesson.Courseware.Video"',
            'LMS.Learning.Lesson.Courseware.Video'
        ];

        for (const marker of markers) {
            const markerIndex = source.indexOf(marker);

            if (markerIndex === -1) {
                continue;
            }

            const objectStart = source.indexOf('{', markerIndex);

            if (objectStart === -1) {
                continue;
            }

            const objectEnd = findObjectEnd(source, objectStart);

            if (objectEnd !== -1) {
                return source.slice(objectStart, objectEnd + 1);
            }
        }

        return '';
    }

    function findValue(patterns, source) {
        for (const pattern of patterns) {
            const match = source.match(pattern);

            if (match && typeof match[1] === 'string') {
                return match[1].trim();
            }
        }

        return '';
    }

    function findNamedValue(name, source) {
        const escapedName = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

        return findValue([
            new RegExp(`(?:^|[^\\w$])["']?${escapedName}["']?\\s*:\\s*["']([^"']*)["']`, 'i'),
            new RegExp(`(?:^|[^\\w$])["']?${escapedName}["']?\\s*:\\s*([^,\\s}]+)`, 'i'),
            new RegExp(`\\b${escapedName}\\b\\s*=\\s*["']([^"']*)["']`, 'i')
        ], source);
    }

    function normalizeCoursewareType(value) {
        if (!value) {
            return '';
        }

        const type = value.trim().replace(/^LMS\.Learning\.Lesson\./i, '');
        return /^Courseware\./i.test(type) ? type : `Courseware.${type}`;
    }

    function getCoursewareType(scriptSource, sourceDocument, pageUrl) {
        const explicitType = getQueryValue('coursewareType', pageUrl)
            || getQueryValue('options[coursewareType]', pageUrl)
            || findNamedValue('coursewareType', scriptSource)
            || findNamedValue('courseware_type', scriptSource);

        if (explicitType) {
            return normalizeCoursewareType(explicitType);
        }

        const typeMarker = scriptSource.match(/\bLMS\.Learning\.Lesson\.Courseware\.([A-Za-z][A-Za-z0-9_]*)\b/);

        if (typeMarker) {
            return `Courseware.${typeMarker[1]}`;
        }

        const domType = sourceDocument.querySelector('[data-courseware-type]')?.getAttribute('data-courseware-type');

        if (domType) {
            return normalizeCoursewareType(domType);
        }

        const hasPdfViewer = Boolean(sourceDocument.querySelector(
            'embed[type="application/pdf"], object[type="application/pdf"], iframe[src*=".pdf" i]'
        ));
        const scriptReferencesPdf = /Courseware\.PDF|(?:^|[\/\s"'`])[^\s"'`]+\.pdf(?:[?#\s"'`]|$)/i.test(scriptSource);

        return hasPdfViewer || scriptReferencesPdf ? 'Courseware.PDF' : '';
    }

    function extractPayloadFromPage(pageUrl, sourceDocument) {
        const parsedUrl = new URL(pageUrl, location.href);
        const scriptSource = getInlineScriptSource(sourceDocument);
        const videoConfigBlock = extractVideoConfigBlock(scriptSource);
        const primarySource = videoConfigBlock || scriptSource;
        const lessonMatch = parsedUrl.pathname.match(SUPPORTED_PATHNAME);
        const lessonId = lessonMatch ? lessonMatch[0].split('/').pop() : findNamedValue('lessonId', scriptSource);
        const coursewareId = getQueryValue('coursewareId', parsedUrl.href) || findNamedValue('coursewareId', scriptSource);
        const courseSiteId = getQueryValue('courseSiteId', parsedUrl.href)
            || getQueryValue('options[courseSiteId]', parsedUrl.href)
            || findNamedValue('courseSiteId', scriptSource);
        const site = getQueryValue('site', parsedUrl.href) || findNamedValue('site', scriptSource);
        const securityToken = findNamedValue('securityToken', scriptSource);
        const coursewareType = getCoursewareType(scriptSource, sourceDocument, parsedUrl.href);
        const getOption = (name) => getQueryValue(name, parsedUrl.href)
            || getQueryValue(`options[${name}]`, parsedUrl.href)
            || findNamedValue(name, scriptSource);

        const isVideoCourseware = hasVideoElement(sourceDocument)
            || hasVideoScriptMarker(sourceDocument)
            || /^Courseware\.Video$/i.test(coursewareType);

        if (isVideoCourseware) {
            const payload = {
                courseSiteId: courseSiteId || findNamedValue('courseSiteId', primarySource),
                courseResultId: findNamedValue('courseResultId', primarySource),
                'options[scheduleId]': getOption('scheduleId') || findNamedValue('scheduleId', primarySource),
                'options[courseId]': getOption('courseId') || findNamedValue('courseId', primarySource),
                'options[classroomId]': getOption('classroomId') || findNamedValue('classroomId', primarySource),
                'options[contentSharingId]': getOption('contentSharingId') || findNamedValue('contentSharingId', primarySource),
                'options[trainingModuleId]': getOption('trainingModuleId') || findNamedValue('trainingModuleId', primarySource),
                site,
                securityToken
            };
            const missingFields = [];

            if (!payload.courseSiteId) {
                missingFields.push('courseSiteId');
            }

            if (!payload.courseResultId) {
                missingFields.push('courseResultId');
            }

            if (!payload.site) {
                missingFields.push('site');
            }

            if (!payload.securityToken) {
                missingFields.push('securityToken');
            }

            return { kind: 'video', payload, missingFields };
        }

        const payload = {
            coursewareId,
            lessonId,
            'options[courseSiteId]': courseSiteId,
            'options[scheduleId]': getOption('scheduleId'),
            'options[courseId]': getOption('courseId'),
            'options[classroomId]': getOption('classroomId'),
            'options[contentSharingId]': getOption('contentSharingId'),
            'options[trainingModuleId]': getOption('trainingModuleId'),
            'options[coursewareId]': coursewareId,
            'options[coursewareType]': coursewareType,
            site,
            securityToken
        };
        const missingFields = [];

        ['coursewareId', 'lessonId', 'options[courseSiteId]', 'options[coursewareType]', 'site', 'securityToken']
            .forEach((field) => {
                if (!payload[field]) {
                    missingFields.push(field);
                }
            });

        return { kind: 'courseware', payload, missingFields };
    }

    function extractPayload() {
        return extractPayloadFromPage(location.href, document);
    }

    function getElementLessonUrl(element) {
        const sources = [
            element.getAttribute('href'),
            element.getAttribute('data-href'),
            element.getAttribute('data-url'),
            element.getAttribute('onclick')
        ].filter(Boolean);

        for (const source of sources) {
            try {
                const directUrl = new URL(source, location.href);
                if (directUrl.origin === location.origin && SUPPORTED_PATHNAME.test(directUrl.pathname)) {
                    return directUrl;
                }
            } catch (_) {
                // The value may be a JavaScript handler containing a URL instead of a URL itself.
            }

            const routeMatch = source.match(/(?:https?:\/\/hcm\.k12online\.vn)?\/\d+\/page\/LMS\/Lesson\/Courseware\/learn\/[^"'`\s)]+/i);
            if (routeMatch) {
                try {
                    const parsedUrl = new URL(routeMatch[0], location.href);
                    if (parsedUrl.origin === location.origin && SUPPORTED_PATHNAME.test(parsedUrl.pathname)) {
                        return parsedUrl;
                    }
                } catch (_) {
                    // Ignore malformed link text and continue checking other attributes.
                }
            }
        }

        return null;
    }

    function getLessonCandidate(element) {
        const row = element.closest(
            '[data-lesson-id], [data-courseware-id], tr, li, [class*="lesson"], [class*="courseware"], [class*="item"]'
        ) || element;
        const nestedLink = row.querySelector('a[href], [data-href], [data-url], [onclick]');
        const pageUrl = getElementLessonUrl(element) || (nestedLink ? getElementLessonUrl(nestedLink) : null);
        const rowLessonId = row.getAttribute('data-lesson-id') || '';
        const rowCoursewareId = row.getAttribute('data-courseware-id') || '';

        if (!pageUrl && !rowLessonId) {
            return null;
        }

        const candidateUrl = pageUrl || new URL(location.href);
        if (!pageUrl) {
            const portalId = location.pathname.match(/^\/(\d+)\//)?.[1];
            if (!portalId) {
                return null;
            }
            candidateUrl.pathname = `/${portalId}/page/LMS/Lesson/Courseware/learn/${encodeURIComponent(rowLessonId)}`;
        }

        const params = candidateUrl.searchParams;
        const rowValues = {
            coursewareId: rowCoursewareId,
            courseSiteId: row.getAttribute('data-course-site-id') || '',
            site: row.getAttribute('data-site') || '',
            coursewareType: row.getAttribute('data-courseware-type') || '',
            scheduleId: row.getAttribute('data-schedule-id') || '',
            courseId: row.getAttribute('data-course-id') || '',
            classroomId: row.getAttribute('data-classroom-id') || '',
            contentSharingId: row.getAttribute('data-content-sharing-id') || '',
            trainingModuleId: row.getAttribute('data-training-module-id') || ''
        };

        Object.entries(rowValues).forEach(([name, value]) => {
            if (value && !params.has(name)) {
                params.set(name, value);
            }
        });

        if (!params.has('courseSiteId')) {
            const courseSiteId = getQueryValue('courseSiteId') || getQueryValue('site');
            if (courseSiteId) {
                params.set('courseSiteId', courseSiteId);
            }
        }
        if (!params.has('site')) {
            const site = getQueryValue('site');
            if (site) {
                params.set('site', site);
            }
        }
        if (!params.has('coursewareId') && rowCoursewareId) {
            params.set('coursewareId', rowCoursewareId);
        }

        const lessonId = pageUrl
            ? candidateUrl.pathname.split('/').pop()
            : rowLessonId;
        const coursewareId = params.get('coursewareId') || rowCoursewareId;
        const courseSiteId = params.get('courseSiteId') || '';
        const site = params.get('site') || '';
        const key = `${lessonId}:${coursewareId || ''}:${courseSiteId}:${site}`;
        const labelContainer = element.closest('tr, li, [class*="lesson"], [class*="courseware"], [class*="item"]') || element;
        const titleText = element.getAttribute('title')
            || element.textContent
            || labelContainer.textContent
            || `Bài học ${lessonId}`;
        const title = titleText.replace(/\s+/g, ' ').trim().slice(0, 140) || `Bài học ${lessonId}`;

        return {
            key,
            title,
            href: candidateUrl.href,
            lessonId,
            coursewareId,
            courseSiteId,
            site,
            coursewareType: params.get('coursewareType') || ''
        };
    }

    function getLessonCandidates() {
        const lessons = new Map();

        if (isCoursewarePageUrl()) {
            const currentPage = new URL(location.href);
            const lessonId = currentPage.pathname.split('/').pop();
            const coursewareId = currentPage.searchParams.get('coursewareId') || '';
            const courseSiteId = currentPage.searchParams.get('courseSiteId') || '';
            const site = currentPage.searchParams.get('site') || '';
            const currentKey = `${lessonId}:${coursewareId}:${courseSiteId}:${site}`;
            lessons.set(currentKey, {
                key: currentKey,
                title: document.title || `Bài học ${lessonId}`,
                href: currentPage.href,
                lessonId,
                coursewareId,
                courseSiteId,
                site,
                coursewareType: currentPage.searchParams.get('coursewareType') || ''
            });
        }

        const primaryList = document.querySelector('#listingModule3');
        const listingModules = primaryList
            ? [primaryList]
            : Array.from(document.querySelectorAll('[id^="listingModule"]'));
        const roots = listingModules.length > 0 ? listingModules : [document.body];
        const elements = new Set();

        roots.forEach((root) => {
            root.querySelectorAll('a[href], [data-href], [data-url], [onclick], [data-lesson-id], [data-courseware-id]').forEach((element) => {
                elements.add(element);
            });
        });

        elements.forEach((element) => {
            const candidate = getLessonCandidate(element);
            if (candidate && !lessons.has(candidate.key)) {
                lessons.set(candidate.key, candidate);
            }
        });

        return Array.from(lessons.values());
    }

    function fillCandidatePayload(request, candidate) {
        const query = new URL(candidate.href, location.href).searchParams;
        const candidateValue = (name) => candidate[name] || query.get(name) || '';

        if (request.kind === 'video') {
            request.payload.courseSiteId ||= candidateValue('courseSiteId');
            request.payload.site ||= candidateValue('site');
            request.missingFields = ['courseSiteId', 'courseResultId', 'site', 'securityToken']
                .filter((field) => !request.payload[field]);
            return request;
        }

        request.payload.coursewareId ||= candidateValue('coursewareId');
        request.payload['options[coursewareId]'] = request.payload.coursewareId;
        request.payload['options[courseSiteId]'] ||= candidateValue('courseSiteId');
        request.payload['options[coursewareType]'] ||= candidateValue('coursewareType');
        request.payload.site ||= candidateValue('site');
        request.payload.lessonId ||= candidate.lessonId || '';
        request.missingFields = ['coursewareId', 'lessonId', 'options[courseSiteId]', 'options[coursewareType]', 'site', 'securityToken']
            .filter((field) => !request.payload[field]);
        return request;
    }

    async function getCandidatePayload(candidate) {
        const lessonUrl = new URL(candidate.href, location.href);
        if (lessonUrl.origin !== location.origin || !SUPPORTED_PATHNAME.test(lessonUrl.pathname)) {
            return { ok: false, message: 'Liên kết bài học không hợp lệ.' };
        }

        let pageUrl = lessonUrl.href;
        let sourceDocument = document;

        if (pageUrl !== location.href) {
            const pageResponse = await fetch(pageUrl, {
                method: 'GET',
                credentials: 'include',
                headers: { Accept: 'text/html,application/xhtml+xml,*/*' }
            });

            if (!pageResponse.ok) {
                return { ok: false, message: `Không tải được bài học (HTTP ${pageResponse.status}).` };
            }

            pageUrl = pageResponse.url || pageUrl;
            const responseUrl = new URL(pageUrl, location.href);
            if (responseUrl.origin !== location.origin || !SUPPORTED_PATHNAME.test(responseUrl.pathname)) {
                return { ok: false, message: 'Trang bài học chuyển hướng hoặc phiên đăng nhập đã hết hạn.' };
            }

            const html = await pageResponse.text();
            sourceDocument = new DOMParser().parseFromString(html, 'text/html');
        }

        const request = fillCandidatePayload(extractPayloadFromPage(pageUrl, sourceDocument), candidate);
        if (request.missingFields.length > 0) {
            return { ok: false, message: `Thiếu dữ liệu: ${request.missingFields.join(', ')}` };
        }

        return { ok: true, request };
    }

    async function completeLessonFromSidebar(candidate) {
        if (state.isRunning) {
            return { ok: false, message: 'Một yêu cầu khác đang chạy.' };
        }

        state.isRunning = true;
        try {
            const prepared = await getCandidatePayload(candidate);
            if (!prepared.ok) {
                return prepared;
            }

            const request = prepared.request;
            const result = request.kind === 'video'
                ? await submitVideoCompletion(request.payload)
                : await submitCoursewareCompletion(request.payload);

            return result.ok
                ? { ok: true, message: request.kind === 'video' ? 'Video đã hoàn tất.' : 'Bài học đã được đánh dấu hoàn thành.' }
                : { ok: false, message: result.message };
        } catch (error) {
            return { ok: false, message: error instanceof Error ? error.message : 'Không gửi được yêu cầu.' };
        } finally {
            state.isRunning = false;
        }
    }

    function createRequestBody(payload) {
        const params = new URLSearchParams();

        Object.entries(payload).forEach(([key, value]) => {
            params.set(key, value == null ? '' : String(value));
        });

        return params;
    }

    async function parseResponse(response) {
        const rawText = await response.text();
        let data = null;

        try {
            data = rawText ? JSON.parse(rawText) : null;
        } catch (error) {
            data = null;
        }

        return { rawText, data };
    }

    function getErrorMessage(response, data, rawText) {
        if (data && typeof data === 'object') {
            const parts = [];

            if (data.status) {
                parts.push(`status=${data.status}`);
            }

            if (typeof data.percent !== 'undefined') {
                parts.push(`percent=${data.percent}`);
            }

            if (data.message) {
                parts.push(data.message);
            }

            if (data.error) {
                parts.push(data.error);
            }

            if (parts.length > 0) {
                return parts.join(' | ');
            }
        }

        const trimmedText = (rawText || '').trim();
        return trimmedText
            ? `HTTP ${response.status}: ${trimmedText.slice(0, 220)}`
            : `HTTP ${response.status}: ${response.statusText || 'Yêu cầu thất bại.'}`;
    }

    async function submitVideoCompletion(payload) {
        const response = await fetch(VIDEO_COMPLETE_ENDPOINT, {
            method: 'POST',
            credentials: 'include',
            headers: {
                Accept: '*/*',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: createRequestBody(payload).toString()
        });

        const { rawText, data } = await parseResponse(response);

        if (!response.ok) {
            return {
                ok: false,
                message: getErrorMessage(response, data, rawText),
                data
            };
        }

        if (data && data.status === 'SUCCESS' && Number(data.percent) === 100) {
            return {
                ok: true,
                data
            };
        }

        return {
            ok: false,
            message: getErrorMessage(response, data, rawText || 'Phản hồi không đúng định dạng mong đợi.'),
            data
        };
    }

    async function submitCoursewareCompletion(payload) {
        const response = await fetch(MARK_COMPLETE_ENDPOINT, {
            method: 'POST',
            credentials: 'include',
            headers: {
                Accept: '*/*',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: createRequestBody(payload).toString()
        });

        const { rawText, data } = await parseResponse(response);

        if (!response.ok) {
            return {
                ok: false,
                message: getErrorMessage(response, data, rawText),
                data
            };
        }

        if (response.redirected && !response.url.includes('/api/LMS/Learning/Courseware/markComplete')) {
            return {
                ok: false,
                message: 'Phiên đăng nhập có thể đã hết hạn. Hãy đăng nhập lại rồi thử tiếp.',
                data
            };
        }

        if (data === false || data === 0 || (data === null && rawText.trim())) {
            return {
                ok: false,
                message: getErrorMessage(response, data, rawText),
                data
            };
        }

        if (data && typeof data === 'object') {
            const status = data.status == null ? '' : String(data.status).toUpperCase();

            if ((status && status !== 'SUCCESS') || data.success === false || data.ok === false || data.error) {
                return {
                    ok: false,
                    message: getErrorMessage(response, data, rawText),
                    data
                };
            }
        }

        return { ok: true, data };
    }

    function getUiElements() {
        return {
            root: document.getElementById(UI_ID),
            button: document.getElementById(BUTTON_ID),
            status: document.getElementById(STATUS_ID)
        };
    }

    function setStatus(message, statusType) {
        const { root, status } = getUiElements();

        if (!status) {
            return;
        }

        status.textContent = message;
        status.dataset.state = statusType;

        if (root) {
            root.dataset.state = statusType;
        }
    }

    function setButtonState(label, disabled) {
        const { button } = getUiElements();

        if (!button) {
            return;
        }

        button.textContent = label;
        button.disabled = disabled;
    }

    async function runProcess() {
        if (state.isRunning) {
            return;
        }

        const request = extractPayload();

        if (request.missingFields.length > 0) {
            setStatus(`Không đủ dữ liệu để gửi request: ${request.missingFields.join(', ')}`, 'error');
            return;
        }

        state.isRunning = true;
        setButtonState('Đang chạy...', true);
        setStatus('Đang gửi yêu cầu hoàn thành bài học...', 'running');

        try {
            const result = request.kind === 'video'
                ? await submitVideoCompletion(request.payload)
                : await submitCoursewareCompletion(request.payload);

            if (result.ok) {
                setStatus(
                    request.kind === 'video'
                        ? 'Video đã hoàn tất. Server trả về status=SUCCESS và percent=100.'
                        : 'Bài học đã được đánh dấu hoàn thành.',
                    'success'
                );
                setButtonState('Hoàn thành lại', false);
                return;
            }

            setStatus(`Lỗi: ${result.message}`, 'error');
            setButtonState('Thử lại', false);
        } catch (error) {
            const message = error instanceof Error ? error.message : 'Không gửi được request.';
            setStatus(`Lỗi: ${message}`, 'error');
            setButtonState('Thử lại', false);
        } finally {
            state.isRunning = false;
        }
    }

    function attachHandlers(root) {
        const button = root.querySelector(`#${BUTTON_ID}`);

        if (!button) {
            return;
        }

        button.addEventListener('click', runProcess);
    }

    function createUi() {
        const existing = document.getElementById(UI_ID);

        if (existing) {
            existing.style.setProperty('display', 'grid', 'important');
            existing.style.setProperty('visibility', 'visible', 'important');
            existing.style.setProperty('opacity', '1', 'important');
            existing.style.setProperty('pointer-events', 'auto', 'important');
            return;
        }

        const container = document.createElement('div');

        container.id = UI_ID;
        container.className = 'k12ext-floating-panel';
        container.dataset.state = 'idle';
        container.innerHTML = [
            '<div class="k12ext-heading">K12 Video Runner</div>',
            '<div class="k12ext-subheading">Hoàn thành bài học ngay bằng một lần bấm.</div>',
            `<button type="button" id="${BUTTON_ID}" class="k12ext-button">Hoàn thành bài</button>`,
            `<div id="${STATUS_ID}" class="k12ext-status" data-state="idle">Sẵn sàng hoàn thành bài học.</div>`
        ].join('');

        document.body.appendChild(container);

        attachHandlers(container);
    }

    function removeUi() {
        const root = document.getElementById(UI_ID);

        if (root) {
            root.remove();
        }
    }

    function ensureUi() {
        if (!state.quickButtonEnabled || !isCoursewarePageUrl()) {
            state.confirmedVideoPage = false;
            state.confirmedUrl = '';
            removeUi();
            stopGuard();
            return;
        }

        detectVideoPage();
        createUi();
        startGuard();
    }

    function startGuard() {
        if (state.guardTimer) {
            return;
        }

        state.guardTimer = setInterval(() => {
            if (!state.quickButtonEnabled || !isCoursewarePageUrl()) {
                stopGuard();
                removeUi();
                return;
            }

            const el = document.getElementById(UI_ID);

            if (!el) {
                createUi();
                return;
            }

            el.style.setProperty('display', 'grid', 'important');
            el.style.setProperty('visibility', 'visible', 'important');
            el.style.setProperty('opacity', '1', 'important');
            el.style.setProperty('pointer-events', 'auto', 'important');
        }, GUARD_INTERVAL_MS);
    }

    function stopGuard() {
        if (state.guardTimer) {
            clearInterval(state.guardTimer);
            state.guardTimer = null;
        }
    }

    function scheduleEnsureUi() {
        window.requestAnimationFrame(() => {
            ensureUi();
        });
    }

    function patchHistory() {
        if (state.historyPatched) {
            return;
        }

        const methods = ['pushState', 'replaceState'];

        methods.forEach((methodName) => {
            const original = history[methodName];

            if (typeof original !== 'function') {
                return;
            }

            history[methodName] = function patchedHistory(...args) {
                const result = original.apply(this, args);
                scheduleEnsureUi();
                return result;
            };
        });

        window.addEventListener('popstate', scheduleEnsureUi);
        window.addEventListener('hashchange', scheduleEnsureUi);

        state.historyPatched = true;
    }

    function observeDomChanges() {
        if (state.observer) {
            return;
        }

        let queued = false;
        state.observer = new MutationObserver(() => {
            if (queued) {
                return;
            }

            queued = true;
            window.requestAnimationFrame(() => {
                queued = false;
                ensureUi();
            });
        });

        state.observer.observe(document.documentElement, {
            childList: true,
            subtree: true
        });
    }

    function setupMessageListener() {
        chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
            if (message.action === 'getLessonCandidates') {
                const lessons = getLessonCandidates();
                sendResponse({
                    ok: true,
                    lessons,
                    message: lessons.length > 0
                        ? `${lessons.length} bài học tìm thấy trên trang.`
                        : 'Trang này chưa có liên kết bài học courseware để chọn.'
                });
                return true;
            }

            if (message.action === 'completeLessonFromSidebar') {
                completeLessonFromSidebar(message.candidate).then(sendResponse);
                return true;
            }

            if (message.action === 'setQuickButtonEnabled') {
                state.quickButtonEnabled = message.enabled !== false;
                ensureUi();
                sendResponse({ ok: true, enabled: state.quickButtonEnabled });
                return true;
            }

            if (message.action === 'getStatus') {
                sendResponse({
                    isCoursewarePage: isCoursewarePageUrl(),
                    isVideoPage: state.confirmedVideoPage || detectVideoPage(),
                    isRunning: state.isRunning,
                    uiPresent: Boolean(document.getElementById(UI_ID))
                });
                return true;
            }

            if (message.action === 'runProcess') {
                if (isCoursewarePageUrl()) {
                    detectVideoPage();
                    ensureUi();
                }

                runProcessFromPopup(sendResponse);
                return true;
            }

            return false;
        });
    }

    async function runProcessFromPopup(sendResponse) {
        if (state.isRunning) {
            sendResponse({ ok: false, message: 'Đang chạy, vui lòng đợi...' });
            return;
        }

        const request = extractPayload();

        if (request.missingFields.length > 0) {
            sendResponse({
                ok: false,
                message: `Không đủ dữ liệu: ${request.missingFields.join(', ')}`
            });
            return;
        }

        state.isRunning = true;
        setButtonState('Đang chạy...', true);
        setStatus('Đang gửi yêu cầu hoàn thành bài học...', 'running');

        try {
            const result = request.kind === 'video'
                ? await submitVideoCompletion(request.payload)
                : await submitCoursewareCompletion(request.payload);

            if (result.ok) {
                const message = request.kind === 'video'
                    ? 'Video đã hoàn tất. status=SUCCESS, percent=100.'
                    : 'Bài học đã được đánh dấu hoàn thành.';
                setStatus(message, 'success');
                setButtonState('Hoàn thành lại', false);
                sendResponse({ ok: true, message });
            } else {
                setStatus(`Lỗi: ${result.message}`, 'error');
                setButtonState('Thử lại', false);
                sendResponse({ ok: false, message: result.message });
            }
        } catch (error) {
            const msg = error instanceof Error ? error.message : 'Không gửi được request.';
            setStatus(`Lỗi: ${msg}`, 'error');
            setButtonState('Thử lại', false);
            sendResponse({ ok: false, message: msg });
        } finally {
            state.isRunning = false;
        }
    }

    function init() {
        patchHistory();
        observeDomChanges();
        setupMessageListener();
        chrome.storage.onChanged.addListener((changes, areaName) => {
            if (areaName === 'local' && changes.k12QuickButtonEnabled) {
                state.quickButtonEnabled = changes.k12QuickButtonEnabled.newValue !== false;
                ensureUi();
            }
        });
        chrome.storage.local.get({ k12QuickButtonEnabled: true })
            .then((settings) => {
                state.quickButtonEnabled = settings.k12QuickButtonEnabled !== false;
                ensureUi();
            })
            .catch(() => ensureUi());
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init, { once: true });
    } else {
        init();
    }
})();
